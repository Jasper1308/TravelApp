const Map<String, String> availableLanguages = {
  'en': 'English',
  'pt': 'Português',
  'es': 'Español',
};
