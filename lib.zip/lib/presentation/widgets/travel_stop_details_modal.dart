import 'package:flutter/material.dart';
import 'package:travel_app/domain/enums/experience_type.dart';
import 'package:travel_app/presentation/widgets/date_input_field.dart';
import 'package:travel_app/presentation/widgets/experience_type_selector.dart';

class TravelStopDetailsModal extends StatefulWidget {
  const TravelStopDetailsModal({super.key});

  @override
  State<TravelStopDetailsModal> createState() => _TravelStopDetailsModalState();
}

class _TravelStopDetailsModalState extends State<TravelStopDetailsModal> {
  DateTime? _arrivalDate;
  DateTime? _departureDate;
  List<ExperienceType> selectedExperiences = [];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.only(
            left: 16.0,
            right: 16.0,
            top: 16.0,
            bottom: MediaQuery.of(context).viewInsets.bottom + 16.0,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                children: [
                  Expanded(
                    child: DateInputField(
                      label: 'chegada',
                      onDateSelected: (date) {
                        setState(() {
                          _arrivalDate = date;
                        });
                      },
                    ),
                  ),
                  Expanded(
                    child: DateInputField(
                      label: 'saida',
                      onDateSelected: (date) {
                        setState(() {
                          _departureDate = date;
                        });
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16.0),
              ExperienceTypeSelector(
                selectedExperiences: [],
                onExperiencesSelected: (experiences) {},
              ),
              const SizedBox(height: 16.0),
              TextFormField(
                decoration: const InputDecoration(
                  labelText: 'Descrição',
                  border: OutlineInputBorder(),
                ),
                maxLines: 5,
              ),
              ElevatedButton(onPressed: () {}, child: Text('Adicionar')),
            ],
          ),
        ),
      ),
    );
  }
}
