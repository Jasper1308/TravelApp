import 'package:firebase_ui_auth/firebase_ui_auth.dart';

class EmailAuthController extends ChangeNotifier {
  String _email = '';
  String _password = '';

  String get email => _email;
  String get password => _password;


}